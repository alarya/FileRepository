﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Web.Http;  // need to add reference
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.IO;

namespace WPFClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        void addFile(string file)
        {
            filelist.Items.Add(file);
        }
        void addFolder(string file)
        {
            folderlist.Items.Add(file);
        }

        private void LoadFilesForDownload(object sender, RoutedEventArgs e)
        {
            var message = new HttpRequestMessage();
            var content = new MultipartFormDataContent();
            message.Method = HttpMethod.Get;
            message.Content = null;
            message.RequestUri = new Uri("http://localhost:46234/api/FilesDownload");

            //SystemSounds.Beep.Play();

            var client = new HttpClient();

            Task<HttpResponseMessage> task = client.SendAsync(message);
            HttpResponseMessage response = task.Result;
            HttpContent reply = response.Content;

            Task<string> t = reply.ReadAsStringAsync();
            string str = t.Result;
            Console.Write("\n  Get Response content: {0}\n", str);

            Console.Write("\n  Server has these files for download:");
            List<string> list = ParseArrayOfJsonObjects(str);

            foreach (string file in list)
            {
                if (Dispatcher.CheckAccess())
                    addFile(file);
                else
                    Dispatcher.Invoke(
                      new Action<string>(addFile),
                      System.Windows.Threading.DispatcherPriority.Background,
                      new string[] { file }
                    );
            }

        }
        static List<string> ParseArrayOfJsonObjects(string str)
        {
            int end, begin = 0;
            List<string> list = new List<string>();
            do
            {
                begin = str.IndexOf('\"', begin) + 1;
                if (begin == 0)
                    break;
                end = str.IndexOf('\"', begin + 1) - 1;
                string temp = str.Substring(begin, end - begin + 1);
                list.Add(temp);
                begin = end + 2;
            } while (begin < str.Count());
            return list;
        }

        private void downloadFile(object sender, RoutedEventArgs e)
        {
            var message = new HttpRequestMessage();
            var content = new MultipartFormDataContent();            
            message.Content = null;
            string baseUri = "http://localhost:46234/api/FilesDownload/";
            message.Method = HttpMethod.Get;

            string downloadfile = filelist.SelectedValue.ToString() ;
            
            var client = new HttpClient();

            baseUri = baseUri + "?path=" + downloadfile;
            message.RequestUri = new Uri(baseUri);
            Task<Stream> task2 = client.GetStreamAsync(message.RequestUri);

            string filename = downloadfile.Split('/')[downloadfile.Split('/').Count()-1];
            
            Stream str2 = task2.Result;
            if (str2 != null)
                MessageBox.Show("File has been saved to received files");
            FileStream fs = new FileStream("../../ReceivedFiles/" + filename, FileMode.Create, FileAccess.ReadWrite);
            str2.CopyTo(fs);
            fs.Seek(0, SeekOrigin.Begin);

            
            StreamReader sr = new StreamReader(fs);
            string fileText = sr.ReadToEnd();
            sr.Close();
            fs.Close();
        }

        private void LoadFoldersForUpload(object sender, RoutedEventArgs e)
        {
            var message = new HttpRequestMessage();
            var content = new MultipartFormDataContent();
            message.Method = HttpMethod.Get;
            message.Content = null;
            message.RequestUri = new Uri("http://localhost:46234/api/FileUpload");

            //SystemSounds.Beep.Play();

            var client = new HttpClient();

            Task<HttpResponseMessage> task = client.SendAsync(message);
            HttpResponseMessage response = task.Result;
            HttpContent reply = response.Content;

            Task<string> t = reply.ReadAsStringAsync();
            string str = t.Result;
            Console.Write("\n  Get Response content: {0}\n", str);

            Console.Write("\n  Server has these files for download:");
            List<string> list = ParseArrayOfJsonObjects(str);

            foreach (string file in list)
            {
                if (Dispatcher.CheckAccess())
                    addFolder(file);
                else
                    Dispatcher.Invoke(
                      new Action<string>(addFolder),
                      System.Windows.Threading.DispatcherPriority.Background,
                      new string[] { file }
                    );
            }

        }
    }
}
